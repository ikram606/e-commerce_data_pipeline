
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.bash import BashOperator

SCRIPTS = [
    "bronze_ingestion.py",
    "silver_orders.py",
    "silver_commerce.py",
    "silver_catalog.py",
    "silver_remaining.py",
    "validate_silver.py",
    "gold_dim_customers.py",
    "gold_dim_date.py",
    "gold_catalog.py",
    "gold_fact_orders.py",
    "enrich_fact_order_items.py",
    "finalize_gold_dates.py",
    "validate_gold.py",
    "export_gold_postgres.py",
]

with DAG(
    dag_id="olist_ecommerce_pipeline",
    start_date=datetime(2026, 10, 1),
    schedule_interval=None,
    catchup=False,
    max_active_runs=1,
    tags=["ecommerce", "spark", "delta", "postgresql"],
) as dag:

    previous_task = None

    for script in SCRIPTS:
        task = BashOperator(
            task_id=script.replace(".py", ""),
            bash_command=(
                f"docker exec ecommerce-spark "
                f"python3 /app/src/{script}"
            ),
            execution_timeout=timedelta(minutes=45),
            retries=0,
        )

        if previous_task is not None:
            previous_task >> task

        previous_task = task
