
import sys
from pyspark.sql import SparkSession
from delta import configure_spark_with_delta_pip
from delta.tables import DeltaTable

# 1. Initialiser Spark + Delta
builder = (
    SparkSession.builder
    .appName("IncrementalOrders")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

# 2. Choisir le batch
if len(sys.argv) != 2 or sys.argv[1] not in ("1", "2"):
    raise ValueError("Utilisation : incremental_orders.py 1 ou 2")

batch_number = sys.argv[1]

batch_path = f"/app/data/batches/orders/batch_{batch_number}"
target_path = "/app/data/processed/orders_current"

# 3. Lire le batch
batch_df = (
    spark.read
    .option("header", True)
    .csv(batch_path)
)

print(f"Batch {batch_number} : {batch_df.count()} lignes")

# 4. Créer ou mettre à jour la table Delta
if not DeltaTable.isDeltaTable(spark, target_path):

    batch_df.write.format("delta").mode("errorifexists").save(target_path)
    print("Table Delta initialisée")

else:

    delta_table = DeltaTable.forPath(spark, target_path)

    
    # Colonnes à comparer (sauf la clé primaire)
    business_columns = [
        c for c in batch_df.columns
        if c != "order_id"
    ]

    # Vérifier si au moins une colonne a changé
    change_condition = " OR ".join(
        f"NOT (target.`{c}` <=> source.`{c}`)"
        for c in business_columns
    )

    # MERGE intelligent
    (
        delta_table.alias("target")
        .merge(
            batch_df.alias("source"),
            "target.order_id = source.order_id"
        )
        .whenMatchedUpdateAll(
            condition=change_condition
        )
        .whenNotMatchedInsertAll()
        .execute()
    )


    print("MERGE terminé")

# 5. Vérifier le résultat
result = spark.read.format("delta").load(target_path)

print("Total dans la table :", result.count())
print(
    "Commandes distinctes :",
    result.select("order_id").distinct().count()
)

spark.stop()
