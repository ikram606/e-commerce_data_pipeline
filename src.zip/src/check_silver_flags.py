
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("CheckSilverFlags")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

df = spark.read.format("delta").load(
    "/app/data/silver/olist/orders"
)

print("Livrées sans date :", df.filter(
    col("missing_delivery_date_flag")
).count())

print("Livraisons en retard :", df.filter(
    col("is_late_delivery")
).count())

spark.stop()