
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, count

spark = (
    SparkSession.builder
    .appName("OlistKeyValidation")
    .master("local[2]")
    .getOrCreate()
)

spark.sparkContext.setLogLevel("ERROR")

base_path = "/app/data/raw/olist/"

def load_table(filename):
    return (
        spark.read
        .option("header", True)
        .csv(base_path + filename)
    )

orders = load_table("olist_orders_dataset.csv")
customers = load_table("olist_customers_dataset.csv")
items = load_table("olist_order_items_dataset.csv")
payments = load_table("olist_order_payments_dataset.csv")
products = load_table("olist_products_dataset.csv")
sellers = load_table("olist_sellers_dataset.csv")

# Vérifier l'unicité des identifiants
def check_key(df, key, table_name):
    total = df.count()
    distinct = df.select(key).distinct().count()

    print(f"\nTABLE : {table_name}")
    print("Lignes :", total)
    print("Clés distinctes :", distinct)
    print("Lignes au-delà des clés distinctes :", total - distinct)

check_key(orders, "order_id", "Orders")
check_key(customers, "customer_id", "Customers")
check_key(products, "product_id", "Products")
check_key(sellers, "seller_id", "Sellers")

# Clé composée pour les articles
check_key(
    items,
    ["order_id", "order_item_id"],
    "Order Items"
)

# Clé composée pour les paiements
check_key(
    payments,
    ["order_id", "payment_sequential"],
    "Payments"
)

# Vérifier les références orphelines
def check_orphans(child, parent, key, label):
    orphan_count = (
        child.join(
            parent.select(key).distinct(),
            on=key,
            how="left_anti"
        )
        .count()
    )

    print(f"{label} : {orphan_count} références orphelines")

print("\nREFERENCES ORPHELINES")

check_orphans(
    orders, customers,
    "customer_id",
    "Orders -> Customers"
)

check_orphans(
    items, orders,
    "order_id",
    "Items -> Orders"
)

check_orphans(
    payments, orders,
    "order_id",
    "Payments -> Orders"
)

check_orphans(
    items, products,
    "product_id",
    "Items -> Products"
)

check_orphans(
    items, sellers,
    "seller_id",
    "Items -> Sellers"
)

spark.stop()
