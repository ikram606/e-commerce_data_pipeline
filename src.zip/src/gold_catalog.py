
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, coalesce, lit
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder.appName("GoldCatalog")
    .master("local[2]")
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
    .config("spark.sql.catalog.spark_catalog",
            "org.apache.spark.sql.delta.catalog.DeltaCatalog")
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

silver = "/app/data/silver/olist"
gold = "/app/data/gold/olist"

products = spark.read.format("delta").load(f"{silver}/products")
sellers = spark.read.format("delta").load(f"{silver}/sellers")
categories = spark.read.format("delta").load(f"{silver}/categories")
items = spark.read.format("delta").load(f"{silver}/order_items")

# 1. Dimension produits avec traduction des catégories
dim_products = (
    products.alias("p")
    .join(
        categories.select(
            "product_category_name",
            "product_category_name_english"
        ).alias("c"),
        "product_category_name",
        "left"
    )
    .select(
        "product_id",
        "product_category_name",
        "product_category_name_english",
        "product_weight_g",
        "product_length_cm",
        "product_height_cm",
        "product_width_cm"
    )
)

# 2. Dimension vendeurs
dim_sellers = sellers.select(
    "seller_id",
    "seller_city",
    "seller_state",
    "seller_zip_code_prefix"
)

# 3. Table de faits détaillée
fact_order_items = (
    items.select(
        "order_id",
        "order_item_id",
        "product_id",
        "seller_id",
        "shipping_limit_date",
        "price",
        "freight_value"
    )
    .withColumn(
        "item_total",
        coalesce(col("price"), lit(0))
        + coalesce(col("freight_value"), lit(0))
    )
)

# 4. Contrôles de granularité
assert dim_products.count() == dim_products.select(
    "product_id"
).distinct().count(), "Doublons dans dim_products"

assert dim_sellers.count() == dim_sellers.select(
    "seller_id"
).distinct().count(), "Doublons dans dim_sellers"

assert fact_order_items.count() == items.count(), (
    "Nombre de lignes modifié dans fact_order_items"
)

assert fact_order_items.select(
    "order_id", "order_item_id"
).distinct().count() == fact_order_items.count(), (
    "Clé composée non unique"
)

# 5. Écriture Gold
for name, df in {
    "dim_products": dim_products,
    "dim_sellers": dim_sellers,
    "fact_order_items": fact_order_items
}.items():
    df.write.format("delta").mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(f"{gold}/{name}")

    print(f"{name} : {df.count()} lignes")

spark.stop()
