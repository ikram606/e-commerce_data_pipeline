
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum as spark_sum, when
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("AnalyzeOrdersQuality")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

df = spark.read.format("delta").load(
    "/app/data/silver/olist/orders"
)

print("\n=== REPARTITION PAR STATUT ===")
df.groupBy("order_status").count().orderBy(
    col("count").desc()
).show(truncate=False)

print("\n=== ANOMALIES POTENTIELLES ===")

df.select(
    spark_sum(
        when(
            (col("order_status") == "delivered")
            & col("order_delivered_customer_date").isNull(),
            1
        ).otherwise(0)
    ).alias("delivered_sans_date"),

    spark_sum(
        when(
            col("order_delivered_customer_date")
            > col("order_estimated_delivery_date"),
            1
        ).otherwise(0)
    ).alias("livraisons_en_retard"),

    spark_sum(
        when(
            col("order_approved_at")
            < col("order_purchase_timestamp"),
            1
        ).otherwise(0)
    ).alias("approbations_avant_achat")
).show(truncate=False)

spark.stop()
