
from pyspark.sql import SparkSession
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("GoldKPIs")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

base = "/app/data/gold/olist"

# Enregistrer les tables Gold comme vues SQL temporaires
for name in [
    "fact_orders",
    "fact_order_items",
    "dim_customers",
    "dim_products",
    "dim_sellers",
    "dim_date"
]:
    df = spark.read.format("delta").load(f"{base}/{name}")
    df.createOrReplaceTempView(name)

print("\n=== KPI COMMANDES ===")

spark.sql("""
SELECT
    COUNT(*) AS total_orders,
    COUNT(DISTINCT customer_id) AS customers,
    ROUND(SUM(payment_total), 2) AS total_payments_brl,
    ROUND(AVG(payment_total), 2) AS avg_payment_brl
FROM fact_orders
""").show(truncate=False)

print("\n=== COMMANDES PAR STATUT ===")

spark.sql("""
SELECT
    order_status,
    COUNT(*) AS orders
FROM fact_orders
GROUP BY order_status
ORDER BY orders DESC
""").show(truncate=False)

print("\n=== COMMANDES PAR MOIS ===")

spark.sql("""
SELECT
    d.year_month,
    COUNT(*) AS total_orders,
    ROUND(SUM(f.payment_total), 2) AS payments_brl
FROM fact_orders f
JOIN dim_date d
    ON f.order_purchase_date = d.date
GROUP BY d.year_month
ORDER BY d.year_month
""").show(50, truncate=False)

print("\n=== TOP 10 CATEGORIES PAR VALEUR DES ARTICLES ===")

spark.sql("""
SELECT
    COALESCE(
        p.product_category_name_english,
        p.product_category_name,
        'Unknown'
    ) AS category,
    COUNT(*) AS items_sold,
    ROUND(SUM(f.price), 2) AS product_value_brl
FROM fact_order_items f
JOIN dim_products p
    ON f.product_id = p.product_id
GROUP BY
    COALESCE(
        p.product_category_name_english,
        p.product_category_name,
        'Unknown'
    )
ORDER BY product_value_brl DESC
LIMIT 10
""").show(truncate=False)

spark.stop()
