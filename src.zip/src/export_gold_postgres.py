
from pyspark.sql import SparkSession
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("ExportGoldPostgres")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

gold_path = "/app/data/gold/olist"

jdbc_url = "jdbc:postgresql://postgres:5432/ecommerce"

properties = {
    "user": "ecommerce_user",
    "password": "ecommerce_dev_password",
    "driver": "org.postgresql.Driver"
}

tables = [
    "dim_customers",
    "dim_products",
    "dim_sellers",
    "dim_date",
    "fact_orders",
    "fact_order_items"
]

for table in tables:
    print(f"\nExport de {table}...")

    df = spark.read.format("delta").load(
        f"{gold_path}/{table}"
    )

    source_count = df.count()

    (
        df.write
        .jdbc(
            url=jdbc_url,
            table=table,
            mode="overwrite",
            properties=properties
        )
    )

    print(f"{table}: {source_count} lignes exportées")

print("\nEXPORT GOLD TERMINE")
spark.stop()
