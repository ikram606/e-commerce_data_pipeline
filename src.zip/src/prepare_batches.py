#cette partie sert a cahrger les donnes historiques et les nouvelles et le merger pour avoir les nouvelles mises a jour en focntion des existaNTES
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

spark = (
    SparkSession.builder
    .appName("PrepareIncrementalBatches")
    .master("local[2]")
    .getOrCreate()
)

spark.sparkContext.setLogLevel("ERROR")

source = "/app/data/raw/olist/olist_orders_dataset.csv"
output = "/app/data/batches/orders"

orders = (
    spark.read
    .option("header", True)
    .csv(source)
)

# Découpage historique en deux lots
batch_1 = orders.filter(
    col("order_purchase_timestamp") < "2018-01-01"
)

batch_2 = orders.filter(
    col("order_purchase_timestamp") >= "2018-01-01"
)

batch_1.write.mode("overwrite").option(
    "header", True
).csv(f"{output}/batch_1")

batch_2.write.mode("overwrite").option(
    "header", True
).csv(f"{output}/batch_2")

print("Batch 1 :", batch_1.count())
print("Batch 2 :", batch_2.count())
print("Total :", orders.count())

spark.stop()
