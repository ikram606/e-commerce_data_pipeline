
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("ValidateGold")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

base = "/app/data/gold/olist"

def load(name):
    return spark.read.format("delta").load(f"{base}/{name}")

def check_unique(table, keys):
    df = load(table)
    total = df.count()
    unique = df.select(*keys).distinct().count()
    print(f"{table}: total={total}, cles_uniques={unique}")
    assert total == unique, f"Doublons dans {table}"

def check_relation(fact, fk, dimension, pk):
    left = load(fact)
    right = load(dimension).select(
        col(pk).alias("_dimension_key")
    )

    missing = left.join(
        right,
        col(fk) == col("_dimension_key"),
        "left_anti"
    ).count()

    print(f"{fact} -> {dimension}: sans correspondance={missing}")
    assert missing == 0, f"Relation invalide : {fact} -> {dimension}"

print("\n=== UNICITE ===")

check_unique("fact_orders", ["order_id"])
check_unique("fact_order_items", ["order_id", "order_item_id"])
check_unique("dim_customers", ["customer_id"])
check_unique("dim_products", ["product_id"])
check_unique("dim_sellers", ["seller_id"])
check_unique("dim_date", ["date"])

print("\n=== RELATIONS ===")

check_relation(
    "fact_orders", "customer_id",
    "dim_customers", "customer_id"
)

check_relation(
    "fact_orders", "order_purchase_date",
    "dim_date", "date"
)

check_relation(
    "fact_order_items", "customer_id",
    "dim_customers", "customer_id"
)

check_relation(
    "fact_order_items", "order_purchase_date",
    "dim_date", "date"
)

check_relation(
    "fact_order_items", "product_id",
    "dim_products", "product_id"
)

check_relation(
    "fact_order_items", "seller_id",
    "dim_sellers", "seller_id"
)

print("\nVALIDATION GOLD TERMINEE")
spark.stop()
