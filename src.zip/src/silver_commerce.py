
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, trim, when, lit, concat_ws,
    current_timestamp
)
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("SilverCommerce")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

bronze_base = "/app/data/bronze/olist"
silver_base = "/app/data/silver/olist"
quarantine_base = "/app/data/quarantine/olist"


def process_table(table_name, casts, required_columns):
    print(f"\n=== {table_name.upper()} ===")

    df = spark.read.format("delta").load(
        f"{bronze_base}/{table_name}"
    )

    bronze_count = df.count()

    # Normaliser les chaînes de caractères
    for column_name, data_type in df.dtypes:
        if data_type == "string" and column_name not in (
            "source_file", "batch_id"
        ):
            df = df.withColumn(
                column_name,
                trim(col(column_name))
            )

    # Convertir les types
    for column_name, target_type in casts.items():
        df = df.withColumn(
            column_name,
            col(column_name).cast(target_type)
        )

    # Contrôler les champs obligatoires
    errors = []

    for column_name in required_columns:
        errors.append(
            when(
                col(column_name).isNull()
                | (col(column_name).cast("string") == ""),
                lit(f"{column_name} manquant ou invalide")
            )
        )

    df = df.withColumn(
        "quality_error",
        concat_ws("; ", *errors)
    )

    valid_df = df.filter(
        col("quality_error") == ""
    ).drop("quality_error")

    invalid_df = (
        df.filter(col("quality_error") != "")
        .withColumn(
            "quarantine_timestamp",
            current_timestamp()
        )
    )

    valid_df.write.format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(f"{silver_base}/{table_name}")

    invalid_df.write.format("delta") \
        .mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(f"{quarantine_base}/{table_name}")

    valid_count = valid_df.count()
    invalid_count = invalid_df.count()

    print("Bronze :", bronze_count)
    print("Silver :", valid_count)
    print("Quarantaine :", invalid_count)

    assert bronze_count == valid_count + invalid_count, (
        f"Perte de lignes dans {table_name}"
    )

    print("Contrôle de conservation : OK")


# CUSTOMERS
process_table(
    "customers",
    casts={
        "customer_zip_code_prefix": "integer"
    },
    required_columns=[
        "customer_id",
        "customer_unique_id"
    ]
)

# ORDER ITEMS
process_table(
    "order_items",
    casts={
        "order_item_id": "integer",
        "price": "decimal(12,2)",
        "freight_value": "decimal(12,2)"
    },
    required_columns=[
        "order_id",
        "order_item_id",
        "product_id",
        "seller_id",
        "price",
        "freight_value"
    ]
)

# PAYMENTS
process_table(
    "payments",
    casts={
        "payment_sequential": "integer",
        "payment_installments": "integer",
        "payment_value": "decimal(12,2)"
    },
    required_columns=[
        "order_id",
        "payment_sequential",
        "payment_value",
        "payment_type"
    ]
)

spark.stop()
