
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("ValidateBusinessRules")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

base = "/app/data/silver/olist"

def load(table):
    return spark.read.format("delta").load(f"{base}/{table}")

def check(table, rule, condition):
    df = load(table)
    count = df.filter(condition).count()
    print(f"{table} | {rule} : {count}")
    return count

print("\n=== CONTROLES METIER SILVER ===")

check(
    "order_items",
    "Prix négatif ou manquant",
    col("price").isNull() | (col("price") < 0)
)

check(
    "order_items",
    "Frais de livraison négatifs ou manquants",
    col("freight_value").isNull() | (col("freight_value") < 0)
)

check(
    "payments",
    "Paiement négatif ou manquant",
    col("payment_value").isNull() | (col("payment_value") < 0)
)

check(
    "payments",
    "Nombre de versements invalide",
    col("payment_installments").isNull()
    | (col("payment_installments") < 0)
)

products = load("products")

for field in [
    "product_weight_g",
    "product_length_cm",
    "product_height_cm",
    "product_width_cm"
]:
    count = products.filter(col(field) < 0).count()
    print(f"products | {field} négatif : {count}")

check(
    "reviews",
    "Note invalide",
    col("review_score").isNull()
    | (~col("review_score").between(1, 5))
)

orders = load("orders")

for field in [
    "missing_delivery_date_flag",
    "is_late_delivery"
]:
    count = orders.filter(col(field) == True).count()
    print(f"orders | {field} : {count}")

print("\nCONTROLES METIER TERMINES")
spark.stop()
