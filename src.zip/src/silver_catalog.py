
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, trim, when, lit, concat_ws, current_timestamp
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder.appName("SilverCatalog")
    .master("local[2]")
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
    .config("spark.sql.catalog.spark_catalog",
            "org.apache.spark.sql.delta.catalog.DeltaCatalog")
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

bronze = "/app/data/bronze/olist"
silver = "/app/data/silver/olist"
quarantine = "/app/data/quarantine/olist"

config = {
    "products": {
        "key": "product_id",
        "casts": {
            "product_name_lenght": "integer",
            "product_description_lenght": "integer",
            "product_photos_qty": "integer",
            "product_weight_g": "double",
            "product_length_cm": "double",
            "product_height_cm": "double",
            "product_width_cm": "double"
        }
    },
    "sellers": {
        "key": "seller_id",
        "casts": {
            "seller_zip_code_prefix": "integer"
        }
    },
    "categories": {
        "key": "product_category_name",
        "casts": {}
    }
}

for name, rules in config.items():
    df = spark.read.format("delta").load(f"{bronze}/{name}")
    original_count = df.count()

    for field, dtype in df.dtypes:
        if dtype == "string" and field not in ("source_file", "batch_id"):
            df = df.withColumn(field, trim(col(field)))

    for field, dtype in rules["casts"].items():
        df = df.withColumn(field, col(field).cast(dtype))

    key = rules["key"]

    df = df.withColumn(
        "quality_error",
        concat_ws(
            "; ",
            when(
                col(key).isNull() | (col(key) == ""),
                lit(f"{key} manquant")
            )
        )
    )

    valid = df.filter(col("quality_error") == "").drop("quality_error")
    invalid = (
        df.filter(col("quality_error") != "")
        .withColumn("quarantine_timestamp", current_timestamp())
    )

    valid.write.format("delta").mode("overwrite") \
        .option("overwriteSchema", "true").save(f"{silver}/{name}")

    invalid.write.format("delta").mode("overwrite") \
        .option("overwriteSchema", "true").save(f"{quarantine}/{name}")

    valid_count = valid.count()
    invalid_count = invalid.count()

    assert original_count == valid_count + invalid_count

    print(
        f"{name}: Bronze={original_count}, "
        f"Silver={valid_count}, Quarantaine={invalid_count}"
    )

spark.stop()
