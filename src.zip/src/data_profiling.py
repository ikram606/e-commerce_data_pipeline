
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, sum as spark_sum, when
from pathlib import Path

spark = (
    SparkSession.builder
    .appName("OlistDataProfiling")
    .master("local[2]")
    .getOrCreate()
)

spark.sparkContext.setLogLevel("ERROR")

data_path = Path("/app/data/raw/olist")

csv_files = sorted(data_path.glob("*.csv"))

for file in csv_files:
    print(f"\n{'=' * 60}")
    print(f"TABLE : {file.name}")
    print(f"{'=' * 60}")

    df = (
        spark.read
        .option("header", True)
        .csv(str(file))
    )

    print("Nombre de lignes :", df.count())
    print("Nombre de colonnes :", len(df.columns))

    print("\nSCHEMA :")
    df.printSchema()

    print("\nEXEMPLE DE DONNEES :")
    df.show(3, truncate=25)

    print("\nVALEURS MANQUANTES :")
    null_counts = df.select([
        spark_sum(
            when(
                col(c).isNull() | (col(c) == ""),
                1
            ).otherwise(0)
        ).alias(c)
        for c in df.columns
    ])

    null_counts.show(truncate=False)

spark.stop()
