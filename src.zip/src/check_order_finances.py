
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, sum as spark_sum, count,
    coalesce, lit, abs as spark_abs
)
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("CheckOrderFinances")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

base = "/app/data/silver/olist"

orders = spark.read.format("delta").load(f"{base}/orders")
items = spark.read.format("delta").load(f"{base}/order_items")
payments = spark.read.format("delta").load(f"{base}/payments")

# 1. Agréger les articles par commande
items_by_order = items.groupBy("order_id").agg(
    count("*").alias("item_count"),
    spark_sum("price").alias("items_value"),
    spark_sum("freight_value").alias("freight_value")
)

# 2. Agréger les paiements par commande
payments_by_order = payments.groupBy("order_id").agg(
    count("*").alias("payment_count"),
    spark_sum("payment_value").alias("payment_total")
)

# 3. Joindre après agrégation
comparison = (
    orders.select("order_id", "order_status")
    .join(items_by_order, "order_id", "left")
    .join(payments_by_order, "order_id", "left")
    .withColumn(
        "items_total",
        coalesce(col("items_value"), lit(0))
        + coalesce(col("freight_value"), lit(0))
    )
    .withColumn(
        "payment_total",
        coalesce(col("payment_total"), lit(0))
    )
    .withColumn(
        "amount_difference",
        spark_abs(col("items_total") - col("payment_total"))
    )
)

print("\n=== GRANULARITE ===")
print("Commandes :", orders.count())
print("Lignes après jointure :", comparison.count())

print("\n=== COMPARAISON FINANCIERE ===")

comparison.select(
    spark_sum("items_total").alias("total_articles_et_livraison"),
    spark_sum("payment_total").alias("total_paiements")
).show(truncate=False)

print("\n=== ECARTS PAR COMMANDE ===")

print(
    "Commandes avec écart > 0.01 :",
    comparison.filter(col("amount_difference") > 0.01).count()
)

print(
    "Commandes sans articles :",
    comparison.filter(col("item_count").isNull()).count()
)

print(
    "Commandes sans paiement :",
    comparison.filter(col("payment_count").isNull()).count()
)

print("\n=== EXEMPLES D'ECARTS ===")

comparison.filter(
    col("amount_difference") > 0.01
).select(
    "order_id",
    "order_status",
    "item_count",
    "payment_count",
    "items_total",
    "payment_total",
    "amount_difference"
).show(10, truncate=False)

spark.stop()
