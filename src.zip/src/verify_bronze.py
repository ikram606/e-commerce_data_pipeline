
import json
from pyspark.sql import SparkSession
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("VerifyBronze")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

with open("/app/config/sources.json") as f:
    config = json.load(f)

for table_name in config["tables"]:
    path = f"{config['bronze_directory']}/{table_name}"

    df = spark.read.format("delta").load(path)

    print(f"\nTABLE : {table_name}")
    print("Lignes :", df.count())

    for column in [
        "ingestion_timestamp",
        "source_file",
        "batch_id"
    ]:
        print(
            f"{column} présent :",
            column in df.columns
        )

    df.select(
        "source_file",
        "batch_id",
        "ingestion_timestamp"
    ).show(1, truncate=False)

spark.stop()
