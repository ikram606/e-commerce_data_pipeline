
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, to_date, year, month,
    quarter, dayofmonth, date_format
)
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("GoldDimDate")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

source = "/app/data/gold/olist/fact_orders"
target = "/app/data/gold/olist/dim_date"

orders = spark.read.format("delta").load(source)

dim_date = (
    orders
    .select(
        to_date("order_purchase_timestamp").alias("date")
    )
    .filter(col("date").isNotNull())
    .distinct()
    .withColumn("year", year("date"))
    .withColumn("quarter", quarter("date"))
    .withColumn("month", month("date"))
    .withColumn("day", dayofmonth("date"))
    .withColumn("year_month", date_format("date", "yyyy-MM"))
    .orderBy("date")
)

dim_date.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(target)

print("=== DIM_DATE ===")
print("Nombre de dates :", dim_date.count())
dim_date.show(5, truncate=False)

spark.stop()
