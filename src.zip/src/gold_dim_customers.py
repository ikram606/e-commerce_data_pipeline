
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("GoldDimCustomers")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

source = "/app/data/silver/olist/customers"
target = "/app/data/gold/olist/dim_customers"

customers = spark.read.format("delta").load(source)

dim_customers = customers.select(
    "customer_id",
    "customer_unique_id",
    "customer_zip_code_prefix",
    "customer_city",
    "customer_state"
)

# Vérifier la clé de la dimension
total = dim_customers.count()
distinct_ids = dim_customers.select(
    "customer_id"
).distinct().count()

assert total == distinct_ids, (
    "Doublons détectés dans dim_customers"
)

dim_customers.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(target)

print("=== DIM_CUSTOMERS ===")
print("Lignes :", total)
print("customer_id distincts :", distinct_ids)
print(
    "Clients uniques :",
    dim_customers.select("customer_unique_id")
    .distinct().count()
)

spark.stop()
