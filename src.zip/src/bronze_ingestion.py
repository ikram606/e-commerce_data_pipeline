
import json
from pathlib import Path
from datetime import datetime, timezone

from pyspark.sql import SparkSession
from pyspark.sql.functions import current_timestamp, lit, input_file_name
from delta import configure_spark_with_delta_pip

# 1. Initialiser Spark avec Delta Lake
builder = (
    SparkSession.builder
    .appName("OlistBronzeIngestion")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

# 2. Lire la configuration
with open("/app/config/sources.json", "r") as file:
    config = json.load(file)

source_dir = config["source_directory"]
bronze_dir = config["bronze_directory"]
tables = config["tables"]

# Identifiant du chargement
batch_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

# 3. Parcourir automatiquement les 9 tables
for table_name, filename in tables.items():

    print(f"\nINGESTION : {table_name}")

    source_path = f"{source_dir}/{filename}"
    target_path = f"{bronze_dir}/{table_name}"

    # Vérifier l'existence du fichier
    if not Path(source_path).is_file():
        raise FileNotFoundError(source_path)

    # Lire les données brutes
    df = (
        spark.read
        .option("header", True)
        .option("multiLine", True)
        .option("escape", '"')
        .csv(source_path)
    )

    # Ajouter les métadonnées techniques
    bronze_df = (
        df.withColumn(
            "ingestion_timestamp",
            current_timestamp()
        )
        .withColumn(
            "source_file",
            lit(filename)
        )
        .withColumn(
            "batch_id",
            lit(batch_id)
        )
    )

    # Enregistrer au format Delta
    (
        bronze_df.write
        .format("delta")
        .mode("overwrite")
        .save(target_path)
    )

    print(f"Table Bronze créée : {target_path}")
    print(f"Nombre de lignes : {bronze_df.count()}")

spark.stop()
