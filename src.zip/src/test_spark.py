
from pyspark.sql import SparkSession

spark = (
    SparkSession.Builder()
    .appName("EcommercePipeline")
    .master("local[2]")
    .getOrCreate()
)

data = [
    (101, "Casablanca", 300),
    (102, "Rabat", 200),
    (103, "Marrakech", 450)
]

df = spark.createDataFrame(
    data,
    ["order_id", "city", "amount"]
)

df.show()

spark.stop()
