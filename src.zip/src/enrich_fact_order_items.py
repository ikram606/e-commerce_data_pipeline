
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, to_date, to_timestamp
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("EnrichFactOrderItems")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

base = "/app/data"

items = spark.read.format("delta").load(
    f"{base}/gold/olist/fact_order_items"
)

orders = spark.read.format("delta").load(
    f"{base}/silver/olist/orders"
)

# Chaque commande possède un client et une date d'achat.
order_info = orders.select(
    "order_id",
    "customer_id",
    to_date("order_purchase_timestamp").alias(
        "order_purchase_date"
    )
)

# Une jointure many-to-one : plusieurs articles
# peuvent appartenir à une même commande.
# Supprimer les colonnes déjà enrichies si elles existent
columns_to_refresh = [
    "customer_id",
    "order_purchase_date"
]

items = items.drop(*columns_to_refresh)

# Recréer les informations à partir des commandes Silver
enriched = (
    items.join(order_info, on="order_id", how="left")
    .withColumn(
        "shipping_limit_date",
        to_timestamp("shipping_limit_date")
    )
)

before = items.count()
after = enriched.count()

missing_customer = enriched.filter(
    col("customer_id").isNull()
).count()

missing_date = enriched.filter(
    col("order_purchase_date").isNull()
).count()

print("Lignes avant :", before)
print("Lignes après :", after)
print("Clients manquants :", missing_customer)
print("Dates manquantes :", missing_date)

assert before == after, "La jointure a modifié le nombre de lignes"
assert missing_customer == 0, "Clients manquants"
assert missing_date == 0, "Dates d'achat manquantes"

# Réécriture de la table Gold enrichie.
enriched.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(f"{base}/gold/olist/fact_order_items")

print("FACT_ORDER_ITEMS ENRICHIE AVEC SUCCES")

spark.stop()
