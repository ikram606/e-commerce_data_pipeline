
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, to_date, year, month, quarter,
    dayofmonth, date_format, sequence,
    explode, min as spark_min, max as spark_max
)
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("FinalizeGoldDates")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

base = "/app/data/gold/olist"

fact_orders = spark.read.format("delta").load(
    f"{base}/fact_orders"
)

# Ajouter la date d'achat sans l'heure.
fact_orders_updated = fact_orders.withColumn(
    "order_purchase_date",
    to_date("order_purchase_timestamp")
)

assert fact_orders_updated.count() == 99441

# Construire un calendrier continu.
bounds = fact_orders_updated.agg(
    spark_min("order_purchase_date").alias("start_date"),
    spark_max("order_purchase_date").alias("end_date")
)

dim_date = (
    bounds
    .select(
        explode(
            sequence(col("start_date"), col("end_date"))
        ).alias("date")
    )
    .withColumn("year", year("date"))
    .withColumn("quarter", quarter("date"))
    .withColumn("month", month("date"))
    .withColumn("day", dayofmonth("date"))
    .withColumn("year_month", date_format("date", "yyyy-MM"))
)

# Vérifier la couverture des dates.
missing_dates = (
    fact_orders_updated
    .select("order_purchase_date")
    .distinct()
    .join(
        dim_date,
        col("order_purchase_date") == col("date"),
        "left_anti"
    )
    .count()
)

assert missing_dates == 0, "Dates absentes du calendrier"

# Écriture Gold.
# Les tables sont petites ou déjà agrégées.
fact_orders_updated.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(f"{base}/fact_orders")

dim_date.write.format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(f"{base}/dim_date")

print("Commandes :", fact_orders_updated.count())
print("Jours dans dim_date :", dim_date.count())
print("Dates sans correspondance :", missing_dates)
print("DIMENSION DATE FINALISEE")

spark.stop()
