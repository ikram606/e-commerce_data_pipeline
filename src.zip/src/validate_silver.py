
from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("ValidateSilver")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

base = "/app/data"
tables = [
    "orders", "customers", "order_items",
    "payments", "products", "sellers",
    "categories", "reviews", "geolocation"
]

def read(layer, name):
    return spark.read.format("delta").load(
        f"{base}/{layer}/olist/{name}"
    )

# 1. Complétude
print("\n=== COMPLETUDE ===")

for name in tables:
    bronze = read("bronze", name).count()
    silver = read("silver", name).count()
    quarantine = read("quarantine", name).count()

    ok = bronze == silver + quarantine

    print(
        f"{name}: Bronze={bronze}, "
        f"Silver={silver}, Quarantaine={quarantine}, "
        f"OK={ok}"
    )

    assert ok, f"Perte ou duplication de lignes : {name}"

# 2. Unicité des clés
print("\n=== UNICITE ===")

keys = {
    "orders": ["order_id"],
    "customers": ["customer_id"],
    "order_items": ["order_id", "order_item_id"],
    "payments": ["order_id", "payment_sequential"],
    "products": ["product_id"],
    "sellers": ["seller_id"],
    "categories": ["product_category_name"]
}

for name, columns in keys.items():
    df = read("silver", name)

    duplicates = (
        df.groupBy(*columns)
        .count()
        .filter(col("count") > 1)
        .count()
    )

    print(f"{name}: groupes de clés dupliquées={duplicates}")
    assert duplicates == 0, f"Clé non unique : {name}"

# 3. Intégrité référentielle
print("\n=== INTEGRITE REFERENTIELLE ===")

relations = [
    ("orders", "customer_id", "customers", "customer_id"),
    ("order_items", "order_id", "orders", "order_id"),
    ("payments", "order_id", "orders", "order_id"),
    ("reviews", "order_id", "orders", "order_id"),
    ("order_items", "product_id", "products", "product_id"),
    ("order_items", "seller_id", "sellers", "seller_id")
]

for child, child_key, parent, parent_key in relations:
    left = read("silver", child)
    right = (
        read("silver", parent)
        .select(col(parent_key).alias("_parent_key"))
        .distinct()
    )

    orphans = (
        left.join(
            right,
            col(child_key) == col("_parent_key"),
            "left_anti"
        )
        .count()
    )

    print(f"{child} -> {parent}: orphelins={orphans}")

    assert orphans == 0, (
        f"Relation invalide : {child} -> {parent}"
    )

print("\nVALIDATION STRUCTURELLE SILVER TERMINEE")
spark.stop()
