
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, trim, to_timestamp, when, lit,
    concat_ws, current_timestamp
)
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder.appName("SilverRemaining")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

bronze = "/app/data/bronze/olist"
silver = "/app/data/silver/olist"
quarantine = "/app/data/quarantine/olist"

# REVIEWS
reviews = spark.read.format("delta").load(f"{bronze}/reviews")

reviews = (
    reviews
    .withColumn("review_id", trim(col("review_id")))
    .withColumn("order_id", trim(col("order_id")))
    .withColumn("review_score", col("review_score").cast("integer"))
    .withColumn(
        "review_creation_date",
        to_timestamp("review_creation_date", "yyyy-MM-dd HH:mm:ss")
    )
    .withColumn(
        "review_answer_timestamp",
        to_timestamp("review_answer_timestamp", "yyyy-MM-dd HH:mm:ss")
    )
)

reviews = reviews.withColumn(
    "quality_error",
    concat_ws(
        "; ",
        when(
            col("review_id").isNull() | (col("review_id") == ""),
            lit("review_id manquant")
        ),
        when(
            col("order_id").isNull() | (col("order_id") == ""),
            lit("order_id manquant")
        ),
        when(
            col("review_score").isNull()
            | (~col("review_score").between(1, 5)),
            lit("note invalide")
        )
    )
)

# GEOLOCATION
geo = spark.read.format("delta").load(f"{bronze}/geolocation")

geo = (
    geo
    .withColumn(
        "geolocation_zip_code_prefix",
        col("geolocation_zip_code_prefix").cast("integer")
    )
    .withColumn("geolocation_lat", col("geolocation_lat").cast("double"))
    .withColumn("geolocation_lng", col("geolocation_lng").cast("double"))
    .withColumn("geolocation_city", trim(col("geolocation_city")))
    .withColumn("geolocation_state", trim(col("geolocation_state")))
)

geo = geo.withColumn(
    "quality_error",
    concat_ws(
        "; ",
        when(
            col("geolocation_zip_code_prefix").isNull(),
            lit("code postal invalide")
        ),
        when(
            col("geolocation_lat").isNull()
            | (~col("geolocation_lat").between(-90, 90)),
            lit("latitude invalide")
        ),
        when(
            col("geolocation_lng").isNull()
            | (~col("geolocation_lng").between(-180, 180)),
            lit("longitude invalide")
        )
    )
)

# Séparation et écriture
for name, df in {
    "reviews": reviews,
    "geolocation": geo
}.items():

    valid = df.filter(col("quality_error") == "").drop("quality_error")
    invalid = (
        df.filter(col("quality_error") != "")
        .withColumn("quarantine_timestamp", current_timestamp())
    )

    bronze_count = df.count()
    valid_count = valid.count()
    invalid_count = invalid.count()

    assert bronze_count == valid_count + invalid_count, (
        f"Perte de lignes dans {name}"
    )

    valid.write.format("delta").mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(f"{silver}/{name}")

    invalid.write.format("delta").mode("overwrite") \
        .option("overwriteSchema", "true") \
        .save(f"{quarantine}/{name}")

    print(f"\n=== {name.upper()} ===")
    print("Bronze :", bronze_count)
    print("Silver :", valid_count)
    print("Quarantaine :", invalid_count)

spark.stop()
