
from pyspark.sql import SparkSession
from delta import configure_spark_with_delta_pip
from delta.tables import DeltaTable

builder = (
    SparkSession.builder
    .appName("CheckDeltaHistory")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

path = "/app/data/processed/orders_current"

delta_table = DeltaTable.forPath(spark, path)

print("\n=== HISTORIQUE DELTA ===")

delta_table.history().select(
    "version",
    "timestamp",
    "operation",
    "operationMetrics"
).show(10, truncate=False)

spark.stop()
