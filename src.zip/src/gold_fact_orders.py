
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, sum as spark_sum, count,
    coalesce, lit, when, abs as spark_abs,
    current_timestamp
)
from delta import configure_spark_with_delta_pip

builder = (
    SparkSession.builder
    .appName("GoldFactOrders")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

silver = "/app/data/silver/olist"
gold = "/app/data/gold/olist/fact_orders"

orders = spark.read.format("delta").load(f"{silver}/orders")
items = spark.read.format("delta").load(f"{silver}/order_items")
payments = spark.read.format("delta").load(f"{silver}/payments")

# 1. Articles agrégés par commande
items_agg = items.groupBy("order_id").agg(
    count("*").alias("item_count"),
    spark_sum("price").alias("items_value"),
    spark_sum("freight_value").alias("freight_value")
)

# 2. Paiements agrégés par commande
payments_agg = payments.groupBy("order_id").agg(
    count("*").alias("payment_count"),
    spark_sum("payment_value").alias("payment_total")
)

# 3. Construction de la table Gold
fact_orders = (
    orders.select(
        "order_id",
        "customer_id",
        "order_status",
        "order_purchase_timestamp",
        "order_delivered_customer_date",
        "order_estimated_delivery_date",
        "missing_delivery_date_flag",
        "is_late_delivery"
    )
    .join(items_agg, "order_id", "left")
    .join(payments_agg, "order_id", "left")
    .withColumn(
        "items_total",
        coalesce(col("items_value"), lit(0))
        + coalesce(col("freight_value"), lit(0))
    )
    .withColumn(
        "amount_difference",
        spark_abs(
            col("items_total")
            - coalesce(col("payment_total"), lit(0))
        )
    )
    .withColumn(
        "has_financial_difference",
        when(
            col("item_count").isNotNull()
            & col("payment_count").isNotNull(),
            col("amount_difference") > lit(0.01)
        ).otherwise(lit(None).cast("boolean"))
    )
    .withColumn(
        "gold_created_at",
        current_timestamp()
    )
)

# 4. Contrôle de granularité
orders_count = orders.count()
fact_count = fact_orders.count()
distinct_count = fact_orders.select("order_id").distinct().count()

print("Commandes Silver :", orders_count)
print("Lignes Gold :", fact_count)
print("IDs distincts Gold :", distinct_count)

assert orders_count == fact_count == distinct_count, (
    "Erreur de granularité dans fact_orders"
)

# 5. Écriture Delta
fact_orders.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(gold)

print("Table Gold fact_orders créée avec succès")

spark.stop()
