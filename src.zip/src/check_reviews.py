
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

spark = (
    SparkSession.builder
    .appName("CheckReviews")
    .master("local[2]")
    .getOrCreate()
)

spark.sparkContext.setLogLevel("ERROR")

path = "/app/data/raw/olist/olist_order_reviews_dataset.csv"

for multiline in [False, True]:
    df = (
        spark.read
        .option("header", True)
        .option("multiLine", multiline)
        .option("escape", '"')
        .csv(path)
    )

    print(f"\n=== multiLine={multiline} ===")

    print("Nombre de lignes :", df.count())

    print(
        "review_id distincts :",
        df.select("review_id").distinct().count()
    )

    print(
        "review_id NULL :",
        df.filter(col("review_id").isNull()).count()
    )

    print(
        "order_id NULL :",
        df.filter(col("order_id").isNull()).count()
    )

    print(
        "Notes invalides :",
        df.filter(
            col("review_score").isNull()
            | ~col("review_score").isin("1", "2", "3", "4", "5")
        ).count()
    )

spark.stop()
