
from pyspark.sql import SparkSession
from pyspark.sql.functions import (
    col, to_timestamp, when, lit, trim,
    concat_ws, current_timestamp
)
from delta import configure_spark_with_delta_pip

# 1. Initialisation Spark + Delta
builder = (
    SparkSession.builder
    .appName("SilverOrders")
    .master("local[2]")
    .config(
        "spark.sql.extensions",
        "io.delta.sql.DeltaSparkSessionExtension"
    )
    .config(
        "spark.sql.catalog.spark_catalog",
        "org.apache.spark.sql.delta.catalog.DeltaCatalog"
    )
)

spark = configure_spark_with_delta_pip(builder).getOrCreate()
spark.sparkContext.setLogLevel("ERROR")

bronze_path = "/app/data/bronze/olist/orders"
silver_path = "/app/data/silver/olist/orders"
quarantine_path = "/app/data/quarantine/olist/orders"

# 2. Lecture Bronze
df = spark.read.format("delta").load(bronze_path)

print("Commandes Bronze :", df.count())

# 3. Conversion des dates
date_columns = [
    "order_purchase_timestamp",
    "order_approved_at",
    "order_delivered_carrier_date",
    "order_delivered_customer_date",
    "order_estimated_delivery_date"
]

for column in date_columns:
    df = df.withColumn(
        column,
        to_timestamp(col(column), "yyyy-MM-dd HH:mm:ss")
    )

# 4. Normalisation des identifiants
df = (
    df
    .withColumn("order_id", trim(col("order_id")))
    .withColumn("customer_id", trim(col("customer_id")))
    .withColumn("order_status", trim(col("order_status")))
)

# 5. Contrôles de qualité
valid_statuses = [
    "created", "approved", "invoiced",
    "processing", "shipped", "delivered",
    "unavailable", "canceled"
]

df = df.withColumn(
    "quality_error",
    concat_ws(
        "; ",
        when(
            col("order_id").isNull() | (col("order_id") == ""),
            lit("order_id manquant")
        ),
        when(
            col("customer_id").isNull() | (col("customer_id") == ""),
            lit("customer_id manquant")
        ),
        when(
            col("order_purchase_timestamp").isNull(),
            lit("date achat invalide")
        ),
        when(
            col("order_status").isNull()
            | (~col("order_status").isin(valid_statuses)),
            lit("statut invalide")
        ),
        when(
            col("order_delivered_customer_date").isNotNull()
            & (
                col("order_delivered_customer_date")
                < col("order_purchase_timestamp")
            ),
            lit("livraison avant achat")
        )
    )
)

# 6. Séparation valides / invalides
valid_df = df.filter(col("quality_error") == "").drop("quality_error")

invalid_df = (
    df.filter(col("quality_error") != "")
    .withColumn("quarantine_timestamp", current_timestamp())
)

# 6 bis. Indicateurs de qualité et de livraison
valid_df = (
    valid_df
    .withColumn(
        "missing_delivery_date_flag",
        (
            (col("order_status") == "delivered")
            & col("order_delivered_customer_date").isNull()
        )
    )
    .withColumn(
        "is_late_delivery",
        (
            col("order_delivered_customer_date").isNotNull()
            & col("order_estimated_delivery_date").isNotNull()
            & (
                col("order_delivered_customer_date")
                > col("order_estimated_delivery_date")
            )
        )
    )
)


# 7. Écriture Delta

valid_df.write \
    .format("delta") \
    .mode("overwrite") \
    .option("overwriteSchema", "true") \
    .save(silver_path)


invalid_df.write.format("delta").mode("overwrite").save(quarantine_path)

# 8. Vérification
bronze_count = df.count()
valid_count = valid_df.count()
invalid_count = invalid_df.count()

print("\n=== QUALITÉ DES COMMANDES ===")
print("Bronze :", bronze_count)
print("Silver :", valid_count)
print("Quarantaine :", invalid_count)
print("Total contrôlé :", valid_count + invalid_count)

assert bronze_count == valid_count + invalid_count, (
    "Erreur : certaines commandes ont été perdues"
)

print("Contrôle de conservation : OK")

spark.stop()
